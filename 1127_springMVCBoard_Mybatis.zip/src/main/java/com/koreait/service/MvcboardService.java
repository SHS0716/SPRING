package com.koreait.service;

import org.springframework.ui.Model;

import com.koreait.vo.MvcboardVO;

public interface MvcboardService {

//	public abstract void execute(MvcboardVO mvcboardVO);		// 인터페이스에서는 public abstract를 붙이지 않아도 컴파일 될때 자동으로 붙는다.
	public abstract void execute(Model model);
	
}
